import com.bingocloud.{ClientConfiguration, Protocol}
import com.bingocloud.auth.BasicAWSCredentials
import com.bingocloud.services.s3.AmazonS3Client
import org.apache.kafka.clients.producer.{KafkaProducer, ProducerRecord}
import org.nlpcn.commons.lang.util.IOUtil

import java.util.Properties

object Helper {
  //s3参数
  val accessKey = "1CFCAF9875058CB03406"
  val secretKey = "WzI3QzFEMjJBMDc5ODdDQ0M2QkZDOUZCNTY1QkNG"
  val endpoint = "http://scut.depts.bingosoft.net:29997"
  val bucket = "chenyantian"
  //要读取的文件
  val key = "demo.txt"

  //kafka参数
  val topic = "mn_buy_ticket_1"
  val bootstrapServers = "bigdata35.depts.bingosoft.net:29035,bigdata36.depts.bingosoft.net:29036,bigdata37.depts.bingosoft.net:29037"

  //从s3中读取文件内容
  def readFile(): String = {
    val credentials = new BasicAWSCredentials(accessKey, secretKey)
    val clientConfiguration = new ClientConfiguration()
    clientConfiguration.setProtocol(Protocol.HTTP)
    val amazonS3Client = new AmazonS3Client(credentials, clientConfiguration)
    amazonS3Client.setEndpoint(endpoint)
    val s3Object = amazonS3Client.getObject(bucket, key)
    IOUtil.getContent(s3Object.getObjectContent, "UTF-8")
  }

  //把数据写入到kafka中
  def produceKafka(s3Content: String): Unit = {
    val props = new Properties
    props.put("bootstrap.servers", bootstrapServers)
    props.put("acks", "all")
    props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer")
    props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer")
    val producer = new KafkaProducer[String, String](props)
    val dataArr = s3Content.split("\n")
    for (s <- dataArr) {
      if (!s.trim.isEmpty) {
        val record = new ProducerRecord[String, String](topic, null, s)
        println("开始生产数据: " + s)
        producer.send(record)
      }
    }
    producer.flush()
    producer.close()
  }

}
