import java.util.{Date, Properties, UUID}
import org.apache.flink.api.common.serialization.SimpleStringSchema
import org.apache.flink.streaming.api.scala._
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer010

import java.sql.{Connection, DriverManager, PreparedStatement}
import org.apache.flink.configuration.Configuration
import org.apache.flink.streaming.api.functions.sink.{RichSinkFunction, SinkFunction}
import org.apache.flink.streaming.api.scala._

case class SensorReading(buy_time: String, buy_address: String, origin: String, destination: String, username: String)
object Main {
  //输入的kafka主题名称
  val inputTopic = "mn_ticket_1"
  //kafka地址
  val bootstrapServers = "bigdata35.depts.bingosoft.net:29035,bigdata36.depts.bingosoft.net:29036,bigdata37.depts.bingosoft.net:29037"

  def main(args: Array[String]): Unit = {
    val env = StreamExecutionEnvironment.getExecutionEnvironment
    env.setParallelism(1)
    val kafkaProperties = new Properties()
    kafkaProperties.put("bootstrap.servers", bootstrapServers)
    kafkaProperties.put("group.id", UUID.randomUUID().toString)
    kafkaProperties.put("auto.offset.reset", "earliest")
    kafkaProperties.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer")
    kafkaProperties.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer")
    val kafkaConsumer = new FlinkKafkaConsumer010[String](inputTopic,
      new SimpleStringSchema, kafkaProperties)
    kafkaConsumer.setCommitOffsetsOnCheckpoints(true)
    val inputKafkaStream = env.addSource(kafkaConsumer)
    val stream = inputKafkaStream.map(data  => {
      val splited = data.split(",")
      SensorReading(splited(0), splited(1), splited(2), splited(3), splited(4))
    })
    stream.addSink(new JDBCSink())
    env.execute()
  }
}

class JDBCSink() extends RichSinkFunction[SensorReading] {
  // 定义sql连接、预编译器
  var conn: Connection = _
  var insertStmt: PreparedStatement = _
  var updateStmt: PreparedStatement = _

  // 初始化，创建连接和预编译语句
  override def open(parameters: Configuration): Unit = {
    super.open(parameters)
    conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/buy_ticket?serverTimezone=UTC", "root", "root")
    insertStmt = conn.prepareStatement("INSERT INTO buy_ticket_table (buy_time, buy_address, origin, destination, username) VALUES (?,?,?,?,?)")
    updateStmt = conn.prepareStatement("UPDATE buy_ticket_table SET origin = ? WHERE name = ?")

  }

  //调用连接
  override def invoke(value: SensorReading, context: SinkFunction.Context[_]): Unit = {
    updateStmt.setString(4, value.username)
    updateStmt.setString(3, value.destination)
    updateStmt.setString(2, value.origin)
    updateStmt.setString(1, value.buy_address)
    updateStmt.setString(0, value.buy_time)
    updateStmt.execute()

    if (!(updateStmt.getUpdateCount == 0)) {
      insertStmt.setString(0, value.buy_time)
      insertStmt.setString(1, value.buy_address)
      insertStmt.setString(2, value.origin)
      insertStmt.setString(3, value.destination)
      insertStmt.setString(4, value.username)
      insertStmt.execute()
    }
  }

  override def close(): Unit = {
    insertStmt.close()
    updateStmt.close()
    conn.close()
  }
}