import java.util.{Properties, UUID}
import org.apache.flink.api.common.serialization.SimpleStringSchema
import org.apache.flink.streaming.api.scala._
import org.apache.flink.streaming.api.windowing.time.Time
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer010

object Main {
  /**
   * Kafka接入的数据不按buy_time排序是因为
   * 这些数据默认是根据上传顺序排列的
   * 并没有特别指定按照buy_time排列
   */
  /**
   * 输入的主题名称
   */
  val inputTopic = "mn_ticket_1"
  /**
   * kafka地址
   */
  val bootstrapServers = "bigdata35.depts.bingosoft.net:29035,bigdata36.depts.bingosoft.net:29036,bigdata37.depts.bingosoft.net:29037"

  def main(args: Array[String]): Unit = {
    val env = StreamExecutionEnvironment.getExecutionEnvironment
    val kafkaProperties = new Properties()
    kafkaProperties.put("bootstrap.servers", bootstrapServers)
    kafkaProperties.put("group.id", UUID.randomUUID().toString)
    kafkaProperties.put("auto.offset.reset", "earliest")
    kafkaProperties.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer")
    kafkaProperties.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer")
    val kafkaConsumer = new FlinkKafkaConsumer010[String](inputTopic,
      new SimpleStringSchema, kafkaProperties)
    kafkaConsumer.setCommitOffsetsOnCheckpoints(true)
    val inputKafkaStream = env.addSource(kafkaConsumer)
    //inputKafkaStream.map(x => println(x))
    val result = inputKafkaStream.map(line => {
      var new_line = line.replace("\"", "")
      (new_line.substring(new_line.indexOf("destination"), new_line.lastIndexOf(",")), 1)
    })
      .keyBy(0)
      .timeWindow(Time.seconds(30))
      .sum(1)
      .print()
    env.execute()
  }
}

