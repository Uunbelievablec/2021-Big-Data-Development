package pojo;

import comm.ConnectionFactory;
import business.ConnectDB_business;
import comm.DBUtils;


import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreeNode;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;
import java.sql.PreparedStatement;
import java.sql.DatabaseMetaData;
import java.sql.ResultSetMetaData;


/**
 * 得到一个组织好的根节点
 */
public class TableTree {
    public static String dbName="Oracle";

    public TreeNode makeTree()	//得到根节点，它的所有子节点都是表名
    {
        Connection conn=null;
        Statement stmt=null;
        ResultSet rs=null;
        DefaultMutableTreeNode root=null;
        DefaultMutableTreeNode node=null;
        List tableList=new ArrayList();
        String sql="";


        sql="show tables";


        try
        {
            root=new DefaultMutableTreeNode("Root");
            conn= ConnectionFactory.getFactory().currentConnection();
            stmt= conn.createStatement();
            rs=stmt.executeQuery(sql);
            while(rs.next())
            {
                tableList.add(rs.getString(1));	//将查出的所有表名放入列表tableList中
            }
            for(Object o:tableList)
            {
                String tableName=(String)o;
//*********test...........
                String str="select  *  from "+tableName;
                System.out.println(str);
//*********test...........
                rs=stmt.executeQuery("select  *  from "+tableName);
                node=outByMetaData(rs,tableName);
                if(node!=null)
                    root.add(node);
            }

        }catch(Exception e)
        {
            e.printStackTrace();
        }finally
        {
            DBUtils.close(rs,stmt, conn);
        }
        return root;
    }

    //得到每一个表名下的所有字段子节点，并将它们放在表名节点下
    public DefaultMutableTreeNode outByMetaData(ResultSet rs,String tableName)
    {
        DefaultMutableTreeNode node1=new DefaultMutableTreeNode(tableName);
        DefaultMutableTreeNode node2 =null;
        try
        {
            ResultSetMetaData rsmd=rs.getMetaData();
            int columnCount=rsmd.getColumnCount();
            for(int i=1;i<=columnCount;i++)
            {
                String columnName=rsmd.getColumnName(i);
                node2 = new DefaultMutableTreeNode(columnName);
                node1.add(node2);
            }
        }catch(Exception e)
        {
            e.printStackTrace();
        }
        return node1;
    }
}
