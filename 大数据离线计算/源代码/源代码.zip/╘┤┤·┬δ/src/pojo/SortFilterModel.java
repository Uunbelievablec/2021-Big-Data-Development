package pojo;

import comm.SqlLogger;

import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableModel;
import java.util.Arrays;

public class SortFilterModel extends AbstractTableModel {
    private TableModel model;
    private int sortColumn;
    private Row[] rows;

    public SortFilterModel(TableModel m)
    {
        model=m;
        rows=new Row[model.getRowCount()];
        for(int i=0;i<rows.length;i++)
        {
            rows[i]=new Row();
            rows[i].index=i;
        }
        SqlLogger.getSqlLogger().writeLog("启用排序过滤模型,实现排序操作。");
    }

    public void sort(int c)	//排序
    {
        sortColumn=c;
        Arrays.sort(rows);	//调用Arrays.sort算法对Row对象进行排序
        //通知所有表格模型监听器(尤其是JTable)，告诉它们表格内容已经发生更改，必须重新绘制
        fireTableDataChanged();
    }

    public Object getValueAt(int r, int c)
    {
        return model.getValueAt(rows[r].index, c);
    }

    public boolean isCellEditable(int r,int c)
    {
        return model.isCellEditable(rows[r].index, c);
    }

    public void setValueAt(Object aValue,int r,int c)
    {
        model.setValueAt(aValue, rows[r].index, c);
    }

    public int getRowCount()
    {
        return model.getRowCount();
    }

    public int getColumnCount() {

        return model.getColumnCount();
    }

    public String getColumnName(int c)
    {
        return model.getColumnName(c);
    }

    public Class getColumnClass(int c)
    {
        return model.getColumnClass(c);
    }

    //将Row作为内部类是因为CompareTo方法需要访问当前的表格模型和当前列
    private class Row implements Comparable<Row>
    {
        public int index;
        public int compareTo(Row other)
        {
            Object a=model.getValueAt(index, sortColumn);
            Object b=model.getValueAt(other.index, sortColumn);
            if(a==null||b==null)		//表格中有空数据时，a、b有可能为null
                return -1;
            if(a.toString().equals("")||b.toString().equals(""))	//表格中数据为空判断
                return 1;
            else if(a instanceof Comparable)	//表格中数据为数字
                return ((Comparable) a).compareTo(b);
            else
                return a.toString().compareTo(b.toString());	//表格中数据为字符串
        }
    }
}
