package pojo;

import comm.SqlLogger;

import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

/**
 * 根据查询结果创建表模型
 */
public class ResultSetTableModel extends AbstractTableModel {
    private ResultSet rs;
    private ResultSetMetaData rsmd;

    public ResultSetTableModel(ResultSet aResultSet)	//构造函数：初始化rs、rsmd
    {
        rs=aResultSet;
        try
        {
            rsmd=rs.getMetaData();
        }catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    public String getColumnName(int c)		//获取列名
    {
        try
        {
            return rsmd.getColumnName(c+1);
        }catch(Exception e)
        {
            e.printStackTrace();
            return "";
        }
    }

    public int getColumnCount()	//获取列的个数
    {
        try
        {
            return rsmd.getColumnCount();
        }catch(Exception e)
        {
            e.printStackTrace();
            return 0;
        }
    }


    public int getRowCount() 	//获取行数
    {
        try
        {
            rs.last();
            return rs.getRow();
        }catch(Exception e)
        {
            e.printStackTrace();
            return 0;
        }

    }

    public Object getValueAt(int r, int c)		//获取第r行，c列的单元格的值
    {
        try
        {
            rs.absolute(r+1);
            return rs.getObject(c+1);
        }catch(Exception e)
        {
            e.printStackTrace();
            return null;
        }
    }

//*****************************************************

    public void setValueAt(Object obj,int r,int c)	//设置表中第r+1行，c+1列的值
    {
        try
        {
            rs.absolute(r+1);
            rs.updateObject(c+1, obj);
            rs.updateRow();
        }catch(Exception e)
        {
            e.printStackTrace();
            JOptionPane.showConfirmDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    @Override
    public boolean isCellEditable(int r, int c) {
        if(c==0)
            return false;
        return true;
    }

    @Override
    public void fireTableCellUpdated(int row, int column) {
        try
        {
            rs.absolute(row+1);
            Object obj=getValueAt(row, column);
            rs.updateObject(column+1, obj);
        }catch(Exception e)
        {
            e.printStackTrace();
        }
        super.fireTableCellUpdated(row, column);
    }

    //*********************************************************

    public void addRow(String[] rowData)	//增加一行
    {
        String str="";
        try
        {
            //		rs.last();
            //		int countnum=rs.getRow();
            //插入一条新记录
            rs.moveToInsertRow();				//将cursor移到InsertRow缓冲区
            for(int i=0;i<rowData.length;i++)	//并创建一条新的空纪录,修改此空记录的各个字段
            {
                rs.updateObject(i+1, rowData[i]);
                if(i!=rowData.length-1)
                    str+=rowData[i]+",";
                else
                    str+=rowData[i];
            }
            rs.insertRow();						//将新纪录刷新到数据库
            SqlLogger.getSqlLogger().writeLog("插入一行数据: "+"insert into "+rsmd.getTableName(1)+" values("+str+");"+"\t成功！");
            //		super.fireTableRowsInserted(1, countnum+1);
            super.fireTableDataChanged();
        }catch(Exception e)
        {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "input Value is not suit for the column!!!", "Error", JOptionPane.ERROR_MESSAGE);
            try
            {
                SqlLogger.getSqlLogger().writeLog("视图中插入一行数据: "+"insert into "+rsmd.getTableName(1)+" values("+str+");"
                        +"\t失败！\nReason:input Value is not suit for the column!!!");
            }catch(Exception ex)
            {
                ex.printStackTrace();
            }
        }
    }

    public void removeRow(int row)		//删除一行
    {
	/*注意：此处应用下面方式来实现删除操作，不能使用sql语句，否则表视图不能改变。
	  原因：model中resultset集合数据未改变。*/
        try
        {
            rs.absolute(row+1);	//将记录子针移至要删除的记录处(视图中记录是从0开始的，而resultset中记录是从1开始的。)
            rs.deleteRow();			//删除记录并刷新数据库
            super.fireTableRowsDeleted(row, row);	//调用父类方法通知视图刷新
            SqlLogger.getSqlLogger().writeLog("删除视图中第"+(row+1)+"行数据: "+"\t成功！");
        }catch(Exception e)
        {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Exception occure,Delete a row failure!!!");
            try
            {
                SqlLogger.getSqlLogger().writeLog("删除视图中第"+(row+1)+"行数据: "+"\t失败！");
            }catch(Exception ex)
            {
                ex.printStackTrace();
            }
        }
    }
}
