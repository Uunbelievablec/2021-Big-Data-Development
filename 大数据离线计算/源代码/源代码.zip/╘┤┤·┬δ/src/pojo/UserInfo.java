package pojo;

public class UserInfo {
    private int id;
    private String username;
    private String password;
    private String database;
    private static String Url;
    private String str=new String("");

    public UserInfo(){}

    public UserInfo(int id,String username,String password,String database,String ipaddress)
    {
        setId(id);
        setUsername(username);
        setPassword(password);
        setDatabase(database);
        setUrl(ipaddress);
    }

    public UserInfo(String username,String password,String database,String ipaddress)
    {
        setUsername(username);
        setPassword(password);
        setDatabase(database);
        setUrl(ipaddress);
    }

    public UserInfo(String username,String password,String address)
    {
        this(username,password,address,null);
    }

    public UserInfo(String username,String password)
    {
        this(username,password,null,null);
    }

    public String getDatabase() {
        return database;
    }


    public void setDatabase(String database) {
        str=database;
        if(database.equals("Oracle"))
            this.database = "oracle.jdbc.driver.OracleDriver";
        if(database.equals("Mysql"))
            this.database = "com.mysql.jdbc.Driver";
        if(database.equals("Spark Sql"))
            this.database = "org.apache.hive.jdbc.HiveDriver";
    }


    public int getId() {
        return id;
    }


    public void setId(int id) {
        if(id==0)
            id=1;
        else
            this.id = id++;
    }


    public String getPassword() {
        return password;
    }


    public void setPassword(String password) {
        if(password==null)
            password="Null";
        else
            this.password = password;
    }


    public String getUrl() {
        return Url;
    }


    public void setUrl(String ipaddress)
    {
        if(str.equals("Oracle"))
            this.Url="jdbc:oracle:thin:@"+ ipaddress;
        if(str.equals("Mysql"))
        {
            int lastindex=ipaddress.lastIndexOf(':');
            if(lastindex!=-1)
            {
                String str1=ipaddress.substring(0, lastindex);//左包括，右不包括
                String str2=ipaddress.substring(lastindex+1, ipaddress.length());
                ipaddress=str1+"/"+str2;
            }
            this.Url="jdbc:mysql://"+ipaddress + "?useUnicode=true&characterEncoding=utf8&serverTimezone=GMT";
        }
        if(str.equals("Spark Sql"))
        {
            int lastindex=ipaddress.lastIndexOf(':');
            if(lastindex!=-1)
            {
                String str1=ipaddress.substring(0, lastindex);
                String str2=ipaddress.substring(lastindex+1, ipaddress.length());
                ipaddress=str1+"/"+str2;
            }
            this.Url="jdbc:hive2://" + ipaddress;
        }

    }


    public String getUsername() {
        return username;
    }


    public void setUsername(String username) {
        if(username==null)
            username="Null";
        else
            this.username = username;
    }

    public void print()
    {
        System.out.println("ID:\t"+id);
        System.out.println("UserName:\t"+username);
        System.out.println("Password:\t"+password);
        System.out.println("Database:\t"+database);
        System.out.println("Url:\t"+Url);
    }
    public static void main(String[] args) {


    }
}
