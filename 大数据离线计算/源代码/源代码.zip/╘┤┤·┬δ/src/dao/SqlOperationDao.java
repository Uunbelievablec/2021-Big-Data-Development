package dao;

import comm.ConnectionFactory;
import comm.DBUtils;
import comm.DynamicRS;
import comm.SqlLogger;

import java.sql.*;

/**
 * 与数据库连接的业务层类
 */
public class SqlOperationDao {
    //DML操作：
    public String select_dataOp(String sql)	//select：使用select命令查询数据
    {
        Connection conn=null;
        Statement stmt=null;
        ResultSet rs=null;
        String str=null;
        try
        {
            conn= ConnectionFactory.getFactory().currentConnection();
            stmt=conn.createStatement();
            rs=stmt.executeQuery(sql);
            str= DynamicRS.out(rs);
            SqlLogger.getSqlLogger().writeLog("查询数据操作："+sql+"\t(成功！)");
        }catch(Exception e)
        {
            e.printStackTrace();
            str=e.toString();
            SqlLogger.getSqlLogger().writeLog("查询数据操作："+sql+"\t(失败！)");
        }finally
        {
            DBUtils.close(rs,stmt,conn);
        }
        return str;
    }

    public String insert_dataOp(String sql)	//insert：使用insert命令插入数据
    {
        Connection conn=null;
        Statement stmt=null;
        String str=null;
        try
        {
            conn=ConnectionFactory.getFactory().currentConnection();
            conn.setAutoCommit(false);	//不自动提交事务
            stmt=conn.createStatement();
            stmt.execute(sql);
            conn.commit();	//提交
            SqlLogger.getSqlLogger().writeLog("插入数据操作："+sql+"\t(成功！)");
        }catch(Exception e)
        {
            try {
                conn.rollback();	//回滚
                SqlLogger.getSqlLogger().writeLog("插入数据操作："+sql+"\t(失败！)");
            } catch (SQLException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
            e.printStackTrace();
            str=e.toString();
        }finally
        {
            DBUtils.close(stmt,conn);
        }
        return str;
    }

    public String update_dataOp(String sql)	//update：使用update命令修改数据
    {
        Connection conn=null;
        Statement stmt=null;
        String str=null;
        try
        {
            conn=ConnectionFactory.getFactory().currentConnection();
            conn.setAutoCommit(false);
            stmt=conn.createStatement();
            stmt.executeUpdate(sql);
            conn.commit();
            SqlLogger.getSqlLogger().writeLog("修改数据操作："+sql+"\t(成功！)");
        }catch(Exception e)
        {
            try {
                conn.rollback();
                SqlLogger.getSqlLogger().writeLog("修改数据操作："+sql+"\t(失败！)");
            } catch (SQLException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
            e.printStackTrace();
            str=e.toString();
        }finally
        {
            DBUtils.close(stmt,conn);
        }
        return str;
    }

    public String delete_dataOp(String sql)	//delete：使用delete命令删除数据
    {
        Connection conn=null;
        Statement stmt=null;
        String str=null;
        try
        {
            conn=ConnectionFactory.getFactory().currentConnection();
            conn.setAutoCommit(false);
            stmt=conn. createStatement();
            stmt.executeUpdate(sql);
            conn.commit();
            SqlLogger.getSqlLogger().writeLog("删除数据操作："+sql+"\t(成功！)");
        }catch(Exception e)
        {
            try {
                conn.rollback();
                SqlLogger.getSqlLogger().writeLog("删除数据操作："+sql+"\t(失败！)");
            } catch (SQLException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
            e.printStackTrace();
            str=e.toString();
        }finally
        {
            DBUtils.close(stmt,conn);
        }
        return str;
    }

    //DDL操作：
    public String create_tableOp(String sql)	//create：使用create命令创建表
    {
        Connection conn=null;
        Statement stmt=null;
        String str=null;
        try
        {
            conn=ConnectionFactory.getFactory().currentConnection();
            conn.setAutoCommit(false);
            stmt=conn.createStatement();
            stmt.executeUpdate(sql);
            conn.commit();
            SqlLogger.getSqlLogger().writeLog("创建表操作："+sql+"\t(成功！)");
        }catch(Exception e)
        {
            try {
                conn.rollback();
                SqlLogger.getSqlLogger().writeLog("创建表操作："+sql+"\t(失败！)");
            } catch (SQLException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
            e.printStackTrace();
            str=e.toString();
        }finally
        {
            DBUtils.close(stmt,conn);
        }
        return str;
    }

    public String alter_tableOp(String sql)throws Exception	//alter：使用alter命令修改表
    {
        Connection conn=null;
        PreparedStatement pstmt=null;
        String str=null;
        try
        {
            conn=ConnectionFactory.getFactory().currentConnection();
            conn.setAutoCommit(false);
            pstmt=conn.prepareStatement(sql);
            pstmt.executeUpdate();
            conn.commit();
            SqlLogger.getSqlLogger().writeLog("修改表操作："+sql+"\t(成功！)");
        }catch(Exception e)
        {
            try {
                conn.rollback();
                SqlLogger.getSqlLogger().writeLog("修改表操作："+sql+"\t(失败！)");
            } catch (SQLException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
            e.printStackTrace();
            str=e.toString();
            throw e;
        }finally
        {
            DBUtils.close(pstmt,conn);
        }
        return str;
    }

    public String drop_tableOp(String sql)	//drop：使用drop命令删除表
    {
        Connection conn=null;
        PreparedStatement pstmt=null;
        String str=null;
        try
        {
            conn=ConnectionFactory.getFactory().currentConnection();
            conn.setAutoCommit(false);
            pstmt=conn.prepareStatement(sql);
            pstmt.executeUpdate();
            conn.commit();
            SqlLogger.getSqlLogger().writeLog("删除表操作："+sql+"\t(成功！)");
        }catch(Exception e)
        {
            try {
                conn.rollback();
                SqlLogger.getSqlLogger().writeLog("删除表操作："+sql+"\t(失败！)");
            } catch (SQLException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
            e.printStackTrace();
            str=e.toString();
        }finally
        {
            DBUtils.close(pstmt,conn);
        }
        return str;
    }
}
