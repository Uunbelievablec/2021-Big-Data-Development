package business;

import dao.SqlOperationDao;

/**
 * 根据用户输入的命令判断是何种操作并调用dao层的相应方法
 */
public class ExeOperation {
    private  SqlOperationDao sod=new SqlOperationDao();	//定义一个dao层变量并初始化
    private final String s1="select";	//定义用于判断命令类型的字符串变量


    public String exe(String string)
    {
        if(string.equals(""))
            return "Input can not be blank!";
        //////////////////////////////////////////////////////////////
        System.out.println(string);//在控制台输出此执行语句
        String[] array=string.split("\\s");	//将string按空格分隔，并放入到array数组中
        String str=new String("110");

        if(array[0].equalsIgnoreCase(s1))	//是select语句
        {
            str=sod.select_dataOp(string);
            return str;
        }



        return "SQL statement is illeagle!";
    }
}
