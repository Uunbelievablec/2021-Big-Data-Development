package business;

import comm.ConnectionFactory;

import java.sql.*;

/**
 * 查询数据库表的信息
 */
public class SearchInfoOfDB {
    private Connection conn=null;
    private Statement stmt=null;

    private ResultSet rs=null;
    private  boolean flag=false;	//检索此数据库是否支持给定结果集类型的标志位

    public String getColumnInfo(String tableName)	//查询表的字段信息
    {
        String string="";		//存放查询到的数据库表的信息，最终用它返回
        int count=0,a_cons=0;
        //count: record the number of columns(记录字段个数)
        //a_cons: store the type of conlumns'constraint(存储字段的约束类型)
        try
        {
            conn= ConnectionFactory.getFactory().currentConnection();
            stmt=conn.createStatement();
            rs=stmt.executeQuery("select  *  from  "+tableName);/////////////////////////////////////////////////////
            ResultSetMetaData rsmd=rs.getMetaData();
            count=rsmd.getColumnCount();
            string+="                                "+tableName+"\n----------------------------------------------------------------------\n";
            string+="ColumnName\t\t"+"Type\t\t"+"Null ?"+"\n----------------------------------------------------------------------\n";
            for(int i=1;i<=count;i++)
            {
                string+=rsmd.getColumnName(i)+"\t\t";
                string+=rsmd.getColumnTypeName(i)+"(";
                string+=rsmd.getColumnDisplaySize(i)+")\t\t";
                //**************be sure whether the column can be null**************
                a_cons=rsmd.isNullable(i);
                if(a_cons==0)	 	//	0: ColumnNoNulls
                    string+="No";
                else if(a_cons==1)	//	1: ColumnNullable
                    string+="Yes";
                else if(a_cons==2)	//	2: ColumnNullableUnknow
                    string+="Unknow";
                string=string+"\n";
            }
        }catch(Exception e)
        {
            e.printStackTrace();
        }
        return string;
    }

    public ResultSet getResultSet(String tableName)	//根据表名查询数据库，返回一个结果集(ResultSet)
    {
        rs=null;
        String str="";	//存放字段名的临时变量
        try
        {
            conn=ConnectionFactory.getFactory().currentConnection();	//获得一个Connection对象
            //*********此处作用：查询表中所有字段名，将它们以逗号隔开放在临时变量str中为下面查询服务
            stmt=conn.createStatement();
            rs=stmt.executeQuery("select * from "+tableName);
            ResultSetMetaData rsmd=rs.getMetaData();
            int count=rsmd.getColumnCount();
            for(int i=1;i<=count;i++)
            {
                str+=rsmd.getColumnName(i);
                if(i!=count)
                    str+=",";
            }
            /////**********
            DatabaseMetaData meta=conn.getMetaData();	//获得数据库的整体综合信息
            if(meta.supportsResultSetType(ResultSet.TYPE_SCROLL_INSENSITIVE))	//检索此数据库是否支持给定结果集类型
            {
                flag=true;
                //创建一个 Statement 对象，该对象将生成具有给定类型、并发性和可保存性的 ResultSet 对象。
                stmt=conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            }
            else
            {
                stmt=conn.createStatement();
                flag=false;
            }
            if(str.equals(""))
                str="*";

            rs=stmt.executeQuery("select "+str+"  from  "+tableName);	//根据表名查询数据库，并返回一个结果集
        }catch(Exception e)
        {
            e.printStackTrace();
        }
        return rs;
    }

    public boolean getFlag()
    {
        return flag;
    }

    public String getColumnTypeName(String tableName,int c)	//获得类型名
    {
        String columnType="";
        try
        {
            ResultSet rs=getResultSet(tableName);
            ResultSetMetaData rsmd=rs.getMetaData();
            columnType=rsmd.getColumnTypeName(c);
            columnType+="("+rsmd.getColumnDisplaySize(c)+")";
            System.out.println(columnType);		//test
        }catch(Exception e)
        {
            e.printStackTrace();
        }
        return columnType;
    }
}
