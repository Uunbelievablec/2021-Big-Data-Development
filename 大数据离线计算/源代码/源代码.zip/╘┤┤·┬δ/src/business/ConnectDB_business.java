package business;
import comm.ConnectionFactory;
import pojo.UserInfo;

import java.sql.Connection;

/**
 * 连接数据库业务层，判断能否连接数据库
 */
public class ConnectDB_business {

    public boolean login(UserInfo user)
    {
        ConnectionFactory factory=ConnectionFactory.getFactory();	//获得Connection工厂
        factory.setDbName(user.getUsername());	//设置工厂连接数据库所使用的用户名
        factory.setDbPassword(user.getPassword());	//设置工厂连接数据库所使用的密码
        factory.setDriver(user.getDatabase());	//设置用户选择的数据库的驱动
        //System.out.println(user.getDatabase());
        factory.setUrl(user.getUrl());		//设置工厂连接数据库所使用的url
        Connection conn=factory.currentConnection();	//获得数据库的连接
        if(conn!=null)	//判断此连接是否为空
            return true;
        return false;
    }


}
