package web;

import business.ExeOperation;
import business.SearchInfoOfDB;
import com.sun.rowset.CachedRowSetImpl;
import pojo.ResultSetTableModel;
import pojo.TableTree;
import pojo.SortFilterModel;

import javax.sql.rowset.CachedRowSet;
import javax.swing.*;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.table.TableColumn;
import javax.swing.table.TableModel;
import javax.swing.tree.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.ResultSet;
import java.util.ArrayList;

public class sqlDemo {
    private JFrame frame;
    private Container contentPane;
    private JTextArea textArea_input,textArea_display;	//textArea_input:输入SQL命令区	; textArea_display:输入命令结果显示区
    private JButton btn_submit,btn_clear,btn_exit;	//命令提交按钮，清屏按钮，退出按钮
    private JScrollPane scroll1,scroll2,pscroll;	//带有滚动条的Panel
    private JMenuBar bar;		//菜单栏
    private JMenu fileMenu,tableMenu; 	//文件、表菜单
    private JMenuItem exitItem;	//file菜单项(退出程序)

    private JMenuItem item_showAllColumns,item_sortByColumn;	//table菜单项(显示所有隐藏列、按列排序)
    private JButton btn_dataMode,btn_editMode;	//数据模式按钮、编辑模式按钮


    private JPopupMenu popup_dataTable;	//数据表弹出菜单
    private JMenuItem pitem_showAllColumns,pitem_sortByColumn;

    private JPopupMenu popup_input;	//textArea_input文本区的弹出菜单
    private JMenuItem input_cut,input_copy,input_paste,input_selectAll,input_clear;

    private JPopupMenu popup_display;	//textArea_display文本区的弹出菜单
    private JMenuItem display_copy,display_selectAll,display_clear;

    TreePath path=null;		//树路径
    private DefaultTreeModel treemodel;	//树模型
    private JTree tree;	// 树

    private JTable table;	//表
    private ResultSetTableModel tablemodel;	//表模型
    private SortFilterModel sorter;	//排序表模型
    private JTextArea textArea_tableInfo;	//表的字段信息显示区
    private ArrayList<TableColumn> removedColumns;	 //存放隐藏列的列表
    private ResultSet rs=null;	//查询数据库后返回的结果集

    private String dataString;	//数据字符串：用于临时保存表的数据信息，便于导出


    public sqlDemo()
    {
        //设置frame参数
        frame=new JFrame("My SQL Query Analizer");
        contentPane=frame.getContentPane();
        frame.setBounds(0, 0, 1000, 700);
        frame.setResizable(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        initGUI();
    }

    public void initGUI()
    {
        contentPane.setLayout(new BorderLayout());//设置内容面板布局
        //初始化菜单变量，并添加菜单
        bar=new JMenuBar();
        fileMenu=new JMenu("文件(F)");//File

        tableMenu=new JMenu("表(B)");//Table

        exitItem=new JMenuItem("退出(E)",'E');	//Exit



        item_showAllColumns=new JMenuItem("显示列(s)",'s');//ShowAllColumns
        item_sortByColumn=new JMenuItem("按列排序(B)",'B');//SortByColumn

        bar.add(fileMenu);

        bar.add(tableMenu);

        fileMenu.addSeparator();	//分隔线
        fileMenu.add(exitItem);


        tableMenu.addSeparator();//分隔线

        tableMenu.add(item_showAllColumns);
        tableMenu.addSeparator();//分隔线
        tableMenu.add(item_sortByColumn);


        //设置菜单快捷键、菜单项加速键
        fileMenu.setMnemonic('F');

        tableMenu.setMnemonic('B');

        exitItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_E, InputEvent.CTRL_MASK));




        item_showAllColumns.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, InputEvent.ALT_MASK));
        item_sortByColumn.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_B, InputEvent.CTRL_MASK));



        //*以下是数据表(Table)的弹出菜单
        popup_dataTable=new JPopupMenu();

        pitem_sortByColumn=new JMenuItem("pitem_sortByColumn");
        pitem_showAllColumns=new JMenuItem("pitem_showAllColumns");


        popup_dataTable.addSeparator();		//分隔线
        popup_dataTable.add(pitem_sortByColumn);
        popup_dataTable.addSeparator();		//分隔线

        popup_dataTable.add(pitem_showAllColumns);

        //以下是文本输入区(textArea)的弹出菜单
        popup_input=new JPopupMenu();	//textArea_input区
        input_cut=new JMenuItem("Cut");
        input_copy=new JMenuItem("Copy");
        input_paste=new JMenuItem("Paste");
        input_selectAll=new JMenuItem("Select All");
        input_clear=new JMenuItem("Clear");

        popup_input.add(input_cut);
        popup_input.add(input_copy);
        popup_input.add(input_paste);
        popup_input.add(input_selectAll);
        popup_input.addSeparator();	//分隔线
        popup_input.add(input_clear);

        popup_display=new JPopupMenu();	//textArea_display区
        display_copy=new JMenuItem("Copy");
        display_selectAll=new JMenuItem("Select All");
        display_clear=new JMenuItem("Clear");

        popup_display.add(display_copy);
        popup_display.add(display_selectAll);
        popup_display.addSeparator();	//分隔线
        popup_display.add(display_clear);
        //##########################
        //*************************************************************************	设置卡片布局按钮

        btn_dataMode=new JButton("Data Mode");
        btn_editMode=new JButton("Edit Mode");
        btn_exit=new JButton("Exit");
        JPanel p_wrap=new JPanel(new BorderLayout());	//包装按钮：btn_dataMode，btn_editMode，btn_exit
        JPanel pmode_btn=new JPanel(new FlowLayout(FlowLayout.LEFT));

        pmode_btn.add(btn_dataMode);
        pmode_btn.add(btn_editMode);
        p_wrap.add(pmode_btn,BorderLayout.WEST);//将退出按钮和pmode_btn包装起来放在一行
        p_wrap.add(btn_exit,BorderLayout.EAST);
        final CardLayout manager=new CardLayout();
        final JPanel pmode=new JPanel(manager);
        final JPanel p_lookover=new JPanel();
        final JPanel p_data=new JPanel(new BorderLayout());
        final JPanel p_edit=new JPanel(new BorderLayout());
        manager.addLayoutComponent(p_lookover, "lookoverMode");
        manager.addLayoutComponent(p_data, "dataMode");
        manager.addLayoutComponent(p_edit, "editMode");

        pmode.add("lookoverMode",p_lookover);         ///Notify设置布局标签与按钮的对应
        pmode.add("dataMode",p_data);
        pmode.add("editMode",p_edit);

        //***********************************************************************完成Panel的嵌套添加
        textArea_tableInfo=new JTextArea();
        textArea_input=new JTextArea(5,15);
        textArea_display=new JTextArea(30,40);
        btn_submit=new JButton("Submit");
        btn_clear=new JButton("Clear");
        scroll1=new JScrollPane(textArea_input,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scroll2=new JScrollPane(textArea_display,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        JPanel p_list=new JPanel(new BorderLayout());	//JPanel的默认布局就是BorderLayout

        JPanel p1=new JPanel(new FlowLayout(FlowLayout.CENTER,100,10));
        p1.add(btn_submit);
        p1.add(btn_clear);
        JPanel p2=new JPanel(new BorderLayout());
        p2.add(scroll1,BorderLayout.CENTER);
        p2.add(p1,BorderLayout.SOUTH);
        JSplitPane sp1=new JSplitPane(JSplitPane.VERTICAL_SPLIT,true);
        sp1.add(scroll2);
        sp1.add(p2);
        p_edit.add(sp1,BorderLayout.CENTER);

        JPanel pp=new JPanel(new BorderLayout());
        pp.add(p_wrap,BorderLayout.NORTH);
        pp.add(pmode,BorderLayout.CENTER);

        JSplitPane sp2=new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,true);
        sp2.add(pp, JSplitPane.RIGHT);
        sp2.add(p_list, JSplitPane.LEFT);

        contentPane.add(bar,BorderLayout.NORTH);
        contentPane.add(sp2,BorderLayout.CENTER);

        //设置按钮工具提示

        btn_dataMode.setToolTipText("数据模式，用于显示当前表的所有数据记录。");
        btn_editMode.setToolTipText("编辑模式，在输入框中输入sql命令，执行sql语句。");
        btn_exit.setToolTipText("退出此应用程序。");
        btn_submit.setToolTipText("提交按钮，用于将输入的sql语句提交到后台执行。");
        btn_clear.setToolTipText("清除按钮，用于清除结果显示框中的内容。");

//############################Create TreeTable and add a listener#################
        TreeNode root=(new TableTree()).makeTree();
        treemodel=new DefaultTreeModel(root);
        tree=new JTree(treemodel);
        //此处scrollPane的类型都必须是..._AS_NEEDED，否则JPanel中内容不会随拖动操作而同时变大或缩小
        JScrollPane scrollPane=new JScrollPane(tree,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        p_list.add(scrollPane,BorderLayout.CENTER);

        int mode=TreeSelectionModel.SINGLE_TREE_SELECTION;	//只能单选节点
        tree.getSelectionModel().setSelectionMode(mode);
        tree.setVisibleRowCount(35);	//设置一次显示行数
        tree.setLocation(0, 0);		//设置树的左上角位置(暂时好像没有起作用)
        tree.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 3));//设置树节点边界
        tree.setBackground(Color.PINK);	//设置树的背景颜色
        //自定义DefaultTreeCellRenderer，并将它设置为tree的元素渲染器
        DefaultTreeCellRenderer render=new DefaultTreeCellRenderer();
        render.setBackgroundNonSelectionColor(Color.GREEN);
        render.setBackgroundSelectionColor(Color.ORANGE);
        tree.setCellRenderer(render);

        tree.addTreeSelectionListener(new TreeSelectionListener()	//为树添加监听器
        {
            public void valueChanged(TreeSelectionEvent e)
            {


                path=tree.getSelectionPath();
                if(path==null)
                    return;
                DefaultMutableTreeNode selectedNode=(DefaultMutableTreeNode)path.getLastPathComponent();
                String tableName=(String)selectedNode.getUserObject();

                if((!selectedNode.isLeaf())&&(selectedNode.getParent()!=null))	//只有点击表节点时才显示表的字段信息
                {
                    String columnInfo=(new SearchInfoOfDB()).getColumnInfo(tableName);
                    //设置textArea_tableInfo组件中背景、字体等属性
                    textArea_tableInfo.setText("");
                    textArea_tableInfo.setBackground(Color.cyan);
                    textArea_tableInfo.setForeground(Color.RED);
                    textArea_tableInfo.setEditable(false);
                    textArea_tableInfo.setFont(new Font(null,Font.BOLD,14));

                    textArea_tableInfo.setText(columnInfo);
                    p_lookover.add(textArea_tableInfo);
                    manager.show(pmode, "lookoverMode");	//显示lookoverMode卡片
                }






                if((!selectedNode.isLeaf())&&(selectedNode.getParent()!=null))	//所选节点是中间节点(Table)
                {


//使选中表节点时就能将构造表模型Treemodel，实例化表table
                    removedColumns.clear();
                    //从成员变量path中获取最后一次被选中表的路径
                    if(path==null)
                        return;
                    if((!selectedNode.isLeaf())&&(selectedNode.getParent()!=null))///
                    {
                        if(pscroll!=null)
                            p_data.remove(pscroll);
                        if(rs!=null)
                        {
                            try
                            {
                                rs.close();
                            }catch(Exception j)
                            {
                                j.printStackTrace();
                            }
                        }
                        SearchInfoOfDB sidb=new SearchInfoOfDB();
                        rs=sidb.getResultSet(tableName);
                        if(sidb.getFlag())
                        {
                            tablemodel=new ResultSetTableModel(rs);
                        }
                        else
                        {
                            try
                            {
                                CachedRowSet crs=new CachedRowSetImpl();
                                crs.populate(rs);
                                tablemodel=new ResultSetTableModel(crs);
                            }catch(Exception ev)
                            {
                                ev.printStackTrace();
                            }
                        }
                        table=new JTable((TableModel) tablemodel);
                        pscroll=new JScrollPane(table);
                        p_data.add(pscroll,BorderLayout.CENTER);

                        table.setGridColor(Color.RED);
                        table.setBackground(Color.GREEN);
                        table.setComponentPopupMenu(popup_dataTable);
                        //设置单元格选择，使单击时可以选中单元格，双击时可以修改单元格的值
                        table.setRowSelectionAllowed(true);		//此处为true允许行选择
                        table.setColumnSelectionAllowed(true);	//允许列选择==>(同时行选择、列选择＝＝单元格选择)
                        table.getSelectionModel().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);//只能单行选择
                    }
                }
            }

        });
        //tree.setComponentPopupMenu(popup);	//设置树的弹出菜单
        removedColumns=new ArrayList<TableColumn>();
        //#########################################################################

        ActionListener btn_listener=new ActionListener()	//定义布局按钮监听器
        {
            public void actionPerformed(ActionEvent e)
            {
                if(e.getSource()==btn_submit)	//确认提交命令
                {
                    String s1=textArea_input.getText().trim();
                    //由于在jdbc的sql语句中不能包括“；”，故此处要做分号去除处理，以防止用户输入的sql语句中含有分号
                    //如果是导入脚本，脚本文件中可能包含多个sql操作语句，故在此处必须要做处理
                    String s=s1;
                    String str="";
                    ArrayList<String> list=new ArrayList<String>();	//list中存放每一个单一sql语句
                    int end_index=0;
                    do
                    {
                        end_index=s1.indexOf(";");
                        if(end_index!=-1)
                        {
                            s=s1.substring(0, end_index);
                            if(s1.length()>end_index+1)
                                s1=s1.substring(end_index+1, s1.length()).trim();
                            else
                                end_index=-1;
                        }else
                        {
                            s=s1;
                        }
                        list.add(s);
                    }while(end_index!=-1);
                    s="";	//清空s
                    for(String st:list)
                    {
                        dataString=(new ExeOperation()).exe(st);
                        str+=dataString+"\n";
                    }
                    list.clear();	//清空list
                    textArea_display.append(str+"\n");
                    dataString=str;	//将查询所得数据信息str放到数据字符串dataString中，用于保存导出。
                }
                if(e.getSource()==btn_clear)	//清屏
                {
                    textArea_display.setText("");
                    textArea_input.grabFocus();
                }
                if(e.getSource()==btn_exit)		//退出程序
                {
                    System.exit(0);
                }
                if(e.getSource()==btn_editMode)	//进入编辑模式
                {
                    manager.show(pmode, "editMode");

                }


                if(e.getSource()==btn_dataMode)	//进入数据显示模式
                {

                    removedColumns.clear();
                    //从成员变量path中获取最后一次被选中表的路径
                    if(path==null)
                        return;
                    DefaultMutableTreeNode selectedNode=(DefaultMutableTreeNode)path.getLastPathComponent();
                    String tableName=(String)selectedNode.getUserObject();

                    if((!selectedNode.isLeaf())&&(selectedNode.getParent()!=null))
                    {
                        if(pscroll!=null)
                            p_data.remove(pscroll);
                        if(rs!=null)
                        {
                            try
                            {
                                rs.close();
                            }catch(Exception j)
                            {
                                j.printStackTrace();
                            }
                        }
                        SearchInfoOfDB sidb=new SearchInfoOfDB();
                        rs=sidb.getResultSet(tableName);
                        if(sidb.getFlag())
                        {
                            tablemodel=new ResultSetTableModel(rs);
                        }
                        else
                        {
                            try
                            {
                                CachedRowSet crs=new CachedRowSetImpl();
                                crs.populate(rs);
                                tablemodel=new ResultSetTableModel(crs);
                            }catch(Exception ev)
                            {
                                ev.printStackTrace();
                            }
                        }

                        table=new JTable((TableModel) tablemodel);
                        pscroll=new JScrollPane(table);
                        p_data.add(pscroll,BorderLayout.CENTER);
                        manager.show(pmode, "dataMode");
                        frame.validate();

                        //为表的表头添加鼠标监听(鼠标双击列表头，使表按列排序)
                        table.getTableHeader().addMouseListener(new MouseAdapter()
                        {
                            public void mouseClicked(MouseEvent event)
                            {
                                if(event.getClickCount()<2)	return;	//check for double click
                                sorter=new SortFilterModel(tablemodel);	//初始化排序表模型
                                int tableColumn=table.columnAtPoint(event.getPoint());	//find column of click

                                //表table装载sorter表模型(********此语句必须放在上一句的下面，否则会出错********)
                                table.setModel(sorter);

                                //translate to table column index and sort
                                int modelColumn=table.convertColumnIndexToModel(tableColumn);
                                sorter.sort(modelColumn);	//根据选中的列进行排序(视图上排序，物理上没有改变)
                            }
                        });


                        table.setGridColor(Color.RED);
                        table.setBackground(Color.GREEN);
                        table.setComponentPopupMenu(popup_dataTable);
                        //设置单元格选择，使单击时可以选中单元格，双击时可以修改单元格的值
                        table.setRowSelectionAllowed(true);		//此处为true允许行选择
                        table.setColumnSelectionAllowed(true);	//允许列选择==>(同时行选择、列选择＝＝单元格选择)
                        table.getSelectionModel().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);//只能单行选择
                    }
                }
            }
        };



        ActionListener menuListener=new ActionListener()	//菜单项监听
        {
            public void actionPerformed(ActionEvent e)
            {





                if(e.getSource()==exitItem)		//退出
                {
                    System.exit(0);
                }

                path=tree.getSelectionPath();	//***************begin

                if(path==null)
                    return;

            }
        };




        ActionListener input_popListener=new ActionListener()	//textArea_input文本区的弹出菜单监听
        {
            public void actionPerformed(ActionEvent e)
            {
                if(e.getSource()==input_cut)
                {
                    textArea_input.cut();
                }
                if(e.getSource()==input_copy)
                {
                    textArea_input.copy();
                }
                if(e.getSource()==input_paste)
                {
                    textArea_input.paste();
                }
                if(e.getSource()==input_selectAll)
                {
                    textArea_input.selectAll();
                }
                if(e.getSource()==input_clear)
                {
                    textArea_input.setText("");
                }
            }
        };

        ActionListener display_popListener=new ActionListener()	//textArea_display文本区的弹出菜单监听
        {
            public void actionPerformed(ActionEvent e)
            {
                if(e.getSource()==display_copy)
                {
                    textArea_display.copy();
                }
                if(e.getSource()==display_selectAll)
                {
                    textArea_display.selectAll();
                }
                if(e.getSource()==display_clear)
                {
                    textArea_display.setText("");
                }
            }
        };

        //textArea_input、textArea_display的监听器，用于控制弹出菜单项cut、copy，弹出菜单项cutItem、copyItem是否可用
        CaretListener textArea_listener=new CaretListener()		//
        {
            public void caretUpdate(CaretEvent e)
            {

            }
        };



        btn_submit.addActionListener(btn_listener);		//为按钮添加监听
        btn_clear.addActionListener(btn_listener);
        btn_exit.addActionListener(btn_listener);
        //btn_lookOverMode.addActionListener(btn_listener);
        //btn_dataMode.addActionListener(btn_listener);
        btn_editMode.addActionListener(btn_listener);


        exitItem.addActionListener(menuListener);

        textArea_input.addCaretListener(textArea_listener);	//为textArea_input、textArea_result添加监听
        textArea_display.addCaretListener(textArea_listener);

        input_cut.addActionListener(input_popListener);		//为textArea_input文本区的弹出菜单项添加监听
        input_copy.addActionListener(input_popListener);
        input_paste.addActionListener(input_popListener);
        input_selectAll.addActionListener(input_popListener);
        input_clear.addActionListener(input_popListener);

        display_copy.addActionListener(display_popListener);	//为textArea_result文本区的弹出菜单项添加监听
        display_selectAll.addActionListener(display_popListener);
        display_clear.addActionListener(display_popListener);
        //**************************************************************************************
        textArea_input.setComponentPopupMenu(popup_input);	//将popup_input设置为textArea_input的弹出菜单
        textArea_display.setComponentPopupMenu(popup_display); //将popup_display设置为textArea_display的弹出菜单

        textArea_display.setRows(25);
        textArea_display.setBackground(Color.LIGHT_GRAY);
        textArea_display.setForeground(Color.RED);
        textArea_display.setEditable(false);
        textArea_display.setLineWrap(true);
        textArea_display.setSelectedTextColor(Color.ORANGE );
        textArea_display.setFont(new Font(null,Font.BOLD,14));
        textArea_input.grabFocus();		///////////////////
        textArea_input.setFont(new Font(null,Font.PLAIN,13));
        textArea_input.setForeground(Color.blue);
        textArea_input.setLineWrap(true);	//打开换行
        textArea_input.setWrapStyleWord(true);//超长行会在字边界处换行
        btn_submit.setBackground(Color.cyan);
        btn_clear.setBackground(Color.cyan);
        btn_exit.setBackground(Color.RED);
    }

    public void go()
    {
        frame.setVisible(true);
    }

    public static void main(String[] args)
    {
        new sqlDemo().go();
    }
}
