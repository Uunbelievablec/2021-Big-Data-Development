package web;
import business.ConnectDB_business;
import comm.SqlLogger;
import pojo.TableTree;
import pojo.UserInfo;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * 登录验证界面
 */
public class Log {
    private JFrame frame;
    private Container contentPane;
    private JLabel lbl_name,lbl_code,lbl_db,lbl_blank;	//标签(用户名、密码、占位)
    private JTextField text_name;	//用户名输入文本框
    private JPasswordField text_code;	//密码框
    private JButton btn_commit,btn_edit,btn_cancel;	//确认按钮、编辑按钮、取消按钮
    private JComboBox cb1;	//数据库选择下拉列表
    private String[] database={"Oracle","Mysql","Spark Sql"};	//String数组：存放供用行选择的数据库类型
    //Oracle:	oracle.jdbc.driver.OracleDriver,
    //Mysql: 	com.mysql.jdbc.Driver
    //Spark Sql: 	org.apache.hive.jdbc.HiveDriver
    private String t_name=null;
    private String t_code=null;
    private String t_db=null;
    private String t_url="jdbc:hive2://bigdata107.depts.bingosoft.net:22107/" + text_name + "_db";	//连接数据库用的url(包括：IP地址和选用的服务数据库名称)
    private static String temp="jdbc:hive2://bigdata107.depts.bingosoft.net:22107/temp";	//暂存变量：用于暂时存放用户单击Edit按钮后对配置文件所做的修改
    //程序中会将此static变量赋给t_url，即：t_url=temp;

    public Log()
    {
        SqlLogger.getSqlLogger().writeLog("Come into Login GUI.....");

        frame=new JFrame("Login Window");
        contentPane=frame.getContentPane();
        frame.setBounds(350,250,300,300);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        initGUI();
    }

    public void initGUI()
    {
        contentPane.setLayout(new BorderLayout());	//设置内容面板布局
        lbl_name=new JLabel("UserName: ");	//初始化JLable变量
        lbl_code=new JLabel("PassWord: ");
        lbl_db=new JLabel("DataBase: ");
        lbl_blank=new JLabel("");

        text_name=new JTextField(20);		//初始化JTextField变量
        text_code=new JPasswordField(20);

        cb1=new JComboBox(database);	//初始化JComboBox变量
        cb1.setEditable(false);	//使列表框不可编辑

        btn_commit=new JButton("Commit");	//初始化JButton变量
        btn_edit=new JButton("Edit");
        btn_cancel=new JButton("Cancel");

        JPanel p1=new JPanel(new GridLayout(3,1,10,20));		//设置暂存面板
        JPanel p2=new JPanel(new GridLayout(3,1,10,20));
        JPanel p3=new JPanel(new FlowLayout(FlowLayout.CENTER,10,20));
        JPanel p4=new JPanel(new BorderLayout());
        JPanel p6=new JPanel(new FlowLayout(FlowLayout.CENTER,20,20));

        p1.add(lbl_name);	//将各组件放置在面板中
        p1.add(lbl_code);
        p1.add(lbl_db);

        p2.add(text_name);
        p2.add(text_code);
        p2.add(cb1);

        p3.add(btn_commit);
        p3.add(btn_edit);
        p3.add(btn_cancel);

        p4.add(p1,BorderLayout.WEST);
        p4.add(p2,BorderLayout.EAST);
        p6.add(lbl_blank);
        contentPane.add(p6,BorderLayout.NORTH);	//将各面板添加到内容面板(contentPane)中
        contentPane.add(p3,BorderLayout.SOUTH);
        contentPane.add(p4,BorderLayout.CENTER);

        ActionListener listener=new ActionListener()		//动作事件监听
        {
            public void actionPerformed(ActionEvent e)
            {
                t_name=text_name.getText().trim();
                t_code=text_code.getText();
                t_db=database[cb1.getSelectedIndex()];


                if(e.getSource()==btn_cancel)
                {
                    text_name.setText("");
                    text_code.setText("");
                    SqlLogger.getSqlLogger().writeLog("Logout Login GUI by cancel.....");
                    System.exit(0);
                }
                if(e.getSource()==btn_edit)
                {
                    ConfigWindow cw=new ConfigWindow(t_url);
                    cw.go();
                    t_url=cw.getAddress();
                }
                if(e.getSource()==btn_commit)
                {
                    System.out.println(t_name+":\t"+t_code);
                    SqlLogger.getSqlLogger().writeLog("LoginName: "+t_name+"\tLoginPassword: "+t_code);

                    if(t_name.equals("")||t_code.equals(""))
                    {
                        JOptionPane.showMessageDialog(null,
                                "Username and Password can't be null! ", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    UserInfo user=new UserInfo();
                    user.setUsername(t_name);
                    user.setPassword(t_code);
                    user.setDatabase(t_db);
                    TableTree.dbName=t_db;		//**保存数据库名**===>add
                    t_url=temp;
                    user.setUrl(t_url);
                    System.out.println("Database: "+user.getDatabase());
                    System.out.println("IPaddress: "+user.getUrl());
                    ConnectDB_business conn=new ConnectDB_business();
                    boolean flag=conn.login(user);
                    if(flag)
                    {
                        new sqlDemo().go();
                        frame.setVisible(false);
                    }
                    else
                    {
                        JOptionPane.showMessageDialog(null,
                                "Login Failure! ", "Wrong",JOptionPane.OK_OPTION);
                        text_name.setText("");
                        text_code.setText("");
                    }
                }
            }
        };
        KeyListener keylistener=new KeyListener()		//键盘监听
        {
            public void keyPressed(KeyEvent e)
            {
                if(KeyEvent.getKeyText(e.getKeyCode()).equals("Enter"))
                {
                    t_name=text_name.getText().trim();
                    t_code=text_code.getText();
                    t_db=database[cb1.getSelectedIndex()];
                    if(e.getSource()==text_name)
                    {
                        text_code.grabFocus();
                        return;
                    }
                    if(e.getSource()==text_code)
                    {
                        btn_commit.grabFocus();
                        return;
                    }
                    if(e.getSource()==btn_commit)
                    {
                        System.out.println(t_name+":\t"+t_code);
                        SqlLogger.getSqlLogger().writeLog("LoginName: "+t_name+"\tLoginPassword: "+t_code);

                        if(t_name.equals("")||t_code.equals(""))
                        {
                            JOptionPane.showMessageDialog(null,
                                    "Username and Password can't be null! ", "Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        }
                        UserInfo user=new UserInfo();
                        user.setUsername(t_name);
                        user.setPassword(t_code);
                        user.setDatabase(t_db);
                        t_url=temp;
                        user.setUrl(t_url);
                        System.out.println("Database: "+user.getDatabase());
                        System.out.println("IPaddress: "+user.getUrl());
                        ConnectDB_business conn=new ConnectDB_business();
                        boolean flag=conn.login(user);
                        if(flag)
                        {
                            new sqlDemo().go();
                            frame.setVisible(false);
                        }
                        else
                        {
                            JOptionPane.showMessageDialog(null,
                                    "Login Failure! ", "Wrong",JOptionPane.OK_OPTION);
                            text_name.setText("");
                            text_code.setText("");
                        }
                    }
                    if(e.getSource()==btn_edit)
                    {
                        ConfigWindow cw=new ConfigWindow(t_url);
                        cw.go();
                        t_url=cw.getAddress();
                    }
                    if(e.getSource()==btn_cancel)
                    {
                        text_name.setText("");
                        text_code.setText("");
                        SqlLogger.getSqlLogger().writeLog("Logout Login GUI by cancel.....");
                        System.exit(0);
                    }
                }
            }
            public void keyReleased(KeyEvent e)
            { }
            public void keyTyped(KeyEvent e)
            { }
        };
        btn_commit.addActionListener(listener);
        btn_edit.addActionListener(listener);
        btn_cancel.addActionListener(listener);
        cb1.setEditable(true);
        text_name.addKeyListener(keylistener);
        text_code.addKeyListener(keylistener);
        btn_commit.addKeyListener(keylistener);
        btn_edit.addKeyListener(keylistener);
        btn_cancel.addKeyListener(keylistener);
    }

    public void go()		//使frame框架可见
    {
        frame.setVisible(true);
    }

    public static String getTemp()
    {
        return temp;
    }
    public static void setTemp(String temp1)
    {
        temp=temp1;
    }

    public static void main(String[] args)
    {
        (new Log()).go();
    }
}
