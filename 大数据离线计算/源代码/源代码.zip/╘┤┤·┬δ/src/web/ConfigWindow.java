package web;
import comm.SqlLogger;


import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


/**
 * 数据库连接配置窗口
 */
public class ConfigWindow {
    private JFrame frame;
    private Container contentPane;
    private JLabel lbl_ip,lbl_port,lbl_DBName,lbl_blank;	//标签(IP、端口、数据库名、占位)
    private JButton btn_commit,btn_cancel;		//确认按钮，取消按钮
    private JComboBox cb_ip,cb_port,cb_DBName;	//ip列表、端口列表、数据库名列表
    private String[] ip={"10.16.1.107","bigdata107.depts.bingosoft.net"};		//ip数组，用于放置在列表中
    private String[] port={"22107","3306"};	//端口号数组，用于放置在列表中
    private String[] DBName={"user03_db","user01_db"};	//数据库名数组，用于放置在列表中
    private String address;

    public ConfigWindow(String address)
    {
        SqlLogger.getSqlLogger().writeLog("Come into ConfigWindow GUI.....");

        frame=new JFrame("Config Window");
        contentPane=frame.getContentPane();
        frame.setBounds(350,250,300,300);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        initGUI();
        this.address=address;
    }

    public void initGUI()
    {
        contentPane.setLayout(new BorderLayout());	//内容面板设置
        lbl_ip=new JLabel("IP :");	//JLabel初始化
        lbl_port=new JLabel("Port :");
        lbl_DBName=new JLabel("DBName :");
        lbl_blank=new JLabel("");

        cb_ip=new JComboBox(ip);		//初始化IP列表
        cb_port=new JComboBox(port);		//初始化端口列表
        cb_DBName=new JComboBox(DBName);	//初始化数据库名列表
        btn_commit=new JButton("Commit");	//初始化确认按钮
        btn_cancel=new JButton("Cancel");		//初始化取消按钮

        JPanel p1=new JPanel(new GridLayout(3,1,5,20));	//初始化Panel
        JPanel p2=new JPanel(new GridLayout(3,1,5,20));
        JPanel p3=new JPanel(new FlowLayout(FlowLayout.CENTER,20,30));
        JPanel p4=new JPanel(new BorderLayout());
        JPanel p5=new JPanel(new FlowLayout(FlowLayout.CENTER,10,20));
        p5.add(lbl_blank);

        p1.add(lbl_ip);		//在Panel中添加组件
        p1.add(lbl_port);
        p1.add(lbl_DBName);

        p2.add(cb_ip);
        p2.add(cb_port);
        p2.add(cb_DBName);

        p3.add(btn_commit);
        p3.add(btn_cancel);


        p4.add(p1,BorderLayout.WEST);
        p4.add(p2,BorderLayout.EAST);

        contentPane.add(p5,BorderLayout.NORTH);	//将Panel添加到内容面板(contentPane)中
        contentPane.add(p3,BorderLayout.SOUTH);
        contentPane.add(p4,BorderLayout.CENTER);

        ActionListener listener=new ActionListener()		//动作监听
        {
            public void actionPerformed(ActionEvent e)
            {
                String t_ip=(String)cb_ip.getSelectedItem();
                String t_port=(String)cb_port.getSelectedItem();
                String t_DBName=(String)cb_DBName.getSelectedItem();

                if(e.getSource()==btn_cancel)
                {
                    frame.setVisible(false);
                    SqlLogger.getSqlLogger().writeLog("Logout ConfigWindow GUI by cancel.....");
                }
                if(e.getSource()==btn_commit)
                {
                    System.out.println("IP: "+t_ip+"\tPort: "+t_port+"\tDBName: "+t_DBName);////////
                    SqlLogger.getSqlLogger().writeLog("IP: "+t_ip+"\tPort: "+t_port+"\tDBName: "+t_DBName);

                    if(t_ip.equals("")||t_port.equals("")||t_DBName.equals(""))
                    {
                        JOptionPane.showMessageDialog(null,
                                "IP、Port and DBName can't be null! ", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    address=t_ip+":"+t_port+":"+t_DBName;
                    System.out.println("Address: "+address);
                    Log.setTemp(address);
                    frame.setVisible(false);
                }
            }
        };

        KeyListener keylistener=new KeyListener()		//键盘监听
        {
            public void keyPressed(KeyEvent e)
            {
                if(KeyEvent.getKeyText(e.getKeyCode()).equals("Enter"))
                {
                    String t_ip=(String)cb_ip.getSelectedItem();
                    String t_port=(String)cb_port.getSelectedItem();
                    String t_DBName=(String)cb_DBName.getSelectedItem();

                    if(e.getSource()==btn_commit)
                    {
                        System.out.println("IP: "+t_ip+"\tPort: "+t_port+"\tDBName: "+t_DBName);///////////////////////////////////////
                        SqlLogger.getSqlLogger().writeLog("IP: "+t_ip+"\tPort: "+t_port+"\tDBName: "+t_DBName);

                        if(t_ip.equals("")||t_port.equals("")||t_DBName.equals(""))
                        {
                            JOptionPane.showMessageDialog(null,
                                    "Username and Password can't be null! ", "Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        }
                        address=t_ip+":"+t_port+":"+t_DBName;
                        System.out.println("Address: "+address);
                        Log.setTemp(address);
                        frame.setVisible(false);
                    }
                    if(e.getSource()==btn_cancel)
                    {
                        frame.setVisible(false);
                        SqlLogger.getSqlLogger().writeLog("Logout ConfigWindow GUI by cancel.....");
                    }
                }
            }
            public void keyReleased(KeyEvent e)
            { }
            public void keyTyped(KeyEvent e)
            { }
        };
        btn_commit.addActionListener(listener);		//为按钮和列表框添加监听
        btn_cancel.addActionListener(listener);
        cb_ip.addKeyListener(keylistener);
        cb_port.addKeyListener(keylistener);
        cb_DBName.addKeyListener(keylistener);
        btn_commit.addKeyListener(keylistener);
        btn_cancel.addKeyListener(keylistener);

        cb_ip.setEditable(true);		//设置列表框的可编辑性
        cb_port.setEditable(true);
        cb_DBName.setEditable(true);
    }

    public void go()
    {
        frame.setVisible(true);
    }

    public  String getAddress()
    {
        return address;
    }
    public static void main(String[] args)
    {
        (new ConfigWindow(null)).go();
    }
}
