package comm;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 * 关闭与数据库的连接并释放资源
 */
public class DBUtils {
    public static void close(ResultSet rs, Statement stmt, Connection conn)
    {
        try
        {
            if(rs!=null)
                rs.close();
            if(stmt!=null)
                stmt.close();
            if(conn!=null)
                conn.close();
        }catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    public static void close(Statement stmt,Connection conn)
    {
        close(null,stmt,conn);
    }
}
