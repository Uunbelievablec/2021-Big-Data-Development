package comm;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 * 采用单例模式获得一个连接工厂，再通过其获得一个数据库连接
 */
public class ConnectionFactory {
    private static ConnectionFactory factory;
    private static String dbName = "user03_db";		//连接的用户名
    private static String dbPassword = "pass@bingo3";	//连接用户名对应的密码
    private static  String driver="org.apache.hive.jdbc.HiveDriver";	//hive数据库驱动
    private static  String url="jdbc:hive2://bigdata107.depts.bingosoft.net:22107/" + dbName;	//连接的url




    public static String getDbName() {
        return dbName;
    }

    public static void setDbName(String dbName) {
        ConnectionFactory.dbName = dbName;
    }

    public static String getDbPassword() {
        return dbPassword;
    }

    public static void setDbPassword(String dbPassword) {
        ConnectionFactory.dbPassword = dbPassword;
    }

    public static String getDriver() {
        return driver;
    }

    public static void setDriver(String driver) {
        ConnectionFactory.driver = driver;
    }

    public static String getUrl() {
        return url;
    }

    public static void setUrl(String url) {
        ConnectionFactory.url = url;
    }

    //单例模式
    private ConnectionFactory()		//私有构造器
    {

    }

    public static ConnectionFactory getFactory()	//获得自身实例的静态(static)方法
    {
        if(factory==null)
            factory=new ConnectionFactory();
        return factory;
    }

    public Connection currentConnection()	//获得与数据库的连接
    {
        Connection conn=null;
        try
        {
            Class.forName(driver);	//注册驱动
            conn= DriverManager.getConnection(url,dbName,dbPassword);//利用已注册驱动获得与数据库的连接
        }catch(Exception e)
        {
            e.printStackTrace();
        }
        return conn;
    }
}
