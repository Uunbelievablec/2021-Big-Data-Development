package comm;
import java.sql.*;

/**
 * 根据给定的ResultSet集合动态查询数据，将数据按一定的格式串联成字符串
 * 最后将此字符串在控制台输出并返回此字符串
 */
public class DynamicRS {
    public static String out(ResultSet rs)
    {
        String str=new String("");
        try {
            ResultSetMetaData rsmd=rs.getMetaData();
            int columnCount=rsmd.getColumnCount();
            boolean flag=true;
            while(rs.next())//rs:指向一行记录====>>rs.next():使rs指向下一行记录
            {
                if(flag==true)
                {
                    int i=0;
                    for(i=1;i<=columnCount;i++)
                    {
                        String columnName=rsmd.getColumnName(i);
                        str+=columnName+"\t";
                    }
                    str+="\n";
                    for(int j=1;j<i;j++)
                    {
                        str+="------------";
                    }
                    str+="\n";
                    flag=false;
                }

                for(int i=1;i<=columnCount;i++)
                {
                    String columnName=rsmd.getColumnName(i);
                    Object o=rs.getObject(i);
                    System.out.print(columnName+":  "+o+"\t");
                    str+=o+"\t";
                }
                System.out.println("\n");
                str=str+"\n";
            }
        } catch (SQLException e) {
            e.printStackTrace();
            str=e.toString();
        }
        return str;
    }
}
