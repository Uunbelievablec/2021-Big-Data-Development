package comm;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.util.Date;

/**
 * 日志记录对象
 */
public class SqlLogger {
    private static SqlLogger sLogger=null;
    private PrintWriter pw=null;

    private SqlLogger()
    {
        try {
            pw=new PrintWriter("src/SqlLog.txt");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static SqlLogger getSqlLogger()
    {
        if(sLogger==null)
            sLogger=new SqlLogger();
        return sLogger;
    }

    public void writeLog(String str)
    {
        Date date=new Date(System.currentTimeMillis());
        String dateString = DateFormat.getDateTimeInstance(DateFormat.MEDIUM,DateFormat.MEDIUM).format(date);
        pw.println(dateString);
        pw.println(str);
        pw.flush();
    }

    public void closeLog()
    {
        pw.close();
    }
}
